package Other_Objects;

public class School {
}
