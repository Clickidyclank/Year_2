package Controllers;

import Tabs.List_tab;

public class List_tab_controller {

    private GeneralController generalController;
    private List_tab list_tab;

    public List_tab_controller(GeneralController generalController, List_tab list_tab) {
        this.generalController = generalController;
        this.list_tab = list_tab;
    }



}
